package com.heretic.voice

import android.content.Context
import android.net.Uri
import android.os.Build
import android.provider.DocumentsContract
import android.util.Log
import ai.heretic.app.assistant.AssistantActionKind
import ai.heretic.app.assistant.RoutedAssistantResult
import ai.heretic.app.assistant.VoiceActionRouter
import ai.heretic.app.core.ErrorAnalysis
import ai.heretic.app.core.FileAssessment
import ai.heretic.app.core.HereticCore
import ai.heretic.app.core.MilestoneItem
import ai.heretic.app.core.MilestoneKind
import ai.heretic.app.core.SolutionConfirmation
import ai.heretic.app.ml.LiteRtEngine
import ai.heretic.app.ml.LiteRtLmEngine
import ai.heretic.app.ml.LiteRtLmModels
import ai.heretic.app.voice.VoiceManager
import com.brahmadeo.supertonic.tts.utils.LexiconItem
import com.brahmadeo.supertonic.tts.utils.LexiconManager
import com.brahmadeo.supertonic.tts.utils.WavUtils
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancel
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import org.json.JSONArray
import org.json.JSONObject
import org.schabi.parakeetype.audio.MicCalibrationResult
import org.schabi.parakeetype.audio.MicScorer
import org.schabi.parakeetype.audio.PermissionHelper
import java.io.BufferedInputStream
import java.io.File
import java.util.concurrent.CopyOnWriteArrayList
import java.util.zip.ZipInputStream

data class AssistantTurn(
    val id: Long,
    val role: String,
    val badge: String,
    val text: String,
    val spokenText: String = "",
)

data class RagChunk(
    val sourcePath: String,
    val pageNumber: Int,
    val content: String,
    val tokens: Set<String>,
)

data class VoicePipelineUiState(
    val paths: VoiceModelPaths,
    val readiness: VoiceModelReadiness,
    val isBusy: Boolean = false,
    val isInitialized: Boolean = false,
    val sttNeuralActive: Boolean = false,
    val llmNeuralActive: Boolean = false,
    val liteRtActive: Boolean = false,
    val liteRtModelLabel: String = "",
    val tfliteSummary: String = "LiteRT 2.3.0 + litert-gpu 2.3.0 ready (TFL3 v3 · GPU -> setNumThreads(4) cached per install)",
    val ttsNeuralActive: Boolean = false,
    val wakeWordRequired: Boolean = true,
    val isListening: Boolean = false,
    val isPlaying: Boolean = false,
    val voiceSpeed: Float = 1.05f,
    val diffusionSteps: Int = 5,
    val availableStyles: List<File> = emptyList(),
    val savedWavs: List<File> = emptyList(),
    val lexiconRules: List<LexiconItem> = emptyList(),
    val milestones: List<MilestoneItem> = emptyList(),
    val micCalibration: MicCalibrationResult? = null,
    val lastErrorAnalysis: ErrorAnalysis? = null,
    val lastSolutionConfirmation: SolutionConfirmation? = null,
    val lastFileAssessment: FileAssessment? = null,
    val requestedTab: Int? = null,
    val statusMessage: String = "Heretic Voice Assistant online. Tap Speak or Hands-Free Mic anytime.",
    val lastUserTranscript: String = "",
    val lastAssistantSentence: String = "",
    val transcriptHistory: List<String> = emptyList(),
    val conversation: List<AssistantTurn> = emptyList(),
    val ragStatus: String = "No RAG files or folders indexed",
    val ragTargetFilter: String = "",
    val ragIndexedFiles: List<String> = emptyList(),
) {
    val activeSttLabel: String
        get() = if (sttNeuralActive) "Parakeet TDT + Silero VAD v6" else "Android Offline STT"

    val activeBrainLabel: String
        get() = when {
            llmNeuralActive -> "llama.cpp GGUF"
            liteRtActive -> "LiteRT-LM ($liteRtModelLabel)"
            else -> "HereticCore Offline"
        }

    val activeTtsLabel: String
        get() = if (ttsNeuralActive) {
            val styleName = File(paths.voiceStylePath).nameWithoutExtension.ifBlank { "M1" }
            "Supertonic ONNX ($styleName)"
        } else {
            "Android Offline TTS"
        }

    val activeWakeLabel: String
        get() = if (wakeWordRequired) "Wake: \"HERETIC\"" else "Wake: Open Mic"
}

class VoicePipelineController(
    context: Context,
    private val core: HereticCore? = null,
    private val platformVoice: VoiceManager? = null,
    private val liteRtEngine: LiteRtLmEngine? = null,
    private val tfliteEngine: LiteRtEngine? = null,
    private val onRequestRecordPermission: (() -> Unit)? = null,
    private val onStateBroadcast: ((VoicePipelineUiState) -> Unit)? = null,
) {
    companion object {
        private const val TAG = "VoicePipelineController"
        private const val MAX_TRANSCRIPT_HISTORY = 32
        private const val MAX_CONVERSATION_TURNS = 60
        private const val PREFS_ASSISTANT = "heretic_assistant_state"
        private const val KEY_MILESTONES = "repo_milestones_json"
        private const val KEY_VOICE_SPEED = "voice_speed"
        private const val KEY_DIFFUSION_STEPS = "diffusion_steps"
        private const val KEY_WAKE_WORD_REQUIRED = "wake_word_required"
        private const val KEY_INITIAL_TTS_GATE = "initial_tts_gate_seeded"
        private const val CHARS_PER_RAG_PAGE = 900
        private const val MAX_TOTAL_RAG_CHUNKS = 400
    }

    private val appContext = context.applicationContext
    private val hereticCore = core ?: HereticCore(appContext)
    private val scope = CoroutineScope(Dispatchers.Main.immediate + SupervisorJob())
    private val controllerLock = Any()
    private val wakeGate: WakeWordSessionGate
    private var turnSeq = 1L

    private var orchestrator: UnifiedVoiceOrchestrator? = null
    private var initializedPaths: VoiceModelPaths? = null

    private val ragChunks = CopyOnWriteArrayList<RagChunk>()

    private val _state: MutableStateFlow<VoicePipelineUiState>
    val state: StateFlow<VoicePipelineUiState>

    init {
        seedInitialAssistantGrants()
        val initialPaths = VoiceModelConfigStore.loadPaths(appContext)
        val initialReadiness = VoiceModelConfigStore.validate(initialPaths)
        val prefs = appContext.getSharedPreferences(PREFS_ASSISTANT, Context.MODE_PRIVATE)
        val savedSpeed = prefs.getFloat(KEY_VOICE_SPEED, 1.05f).coerceIn(0.8f, 1.4f)
        val savedSteps = prefs.getInt(KEY_DIFFUSION_STEPS, 5).coerceIn(2, 8)
        val savedWakeRequired = prefs.getBoolean(KEY_WAKE_WORD_REQUIRED, true)
        wakeGate = WakeWordSessionGate(wakeWordRequired = savedWakeRequired)
        val loadedLexicon = LexiconManager.load(appContext)
        val loadedMilestones = loadPersistedMilestones()
        val styles = discoverAllStyles(File(initialPaths.ttsModelDir))

        val welcomeTurn = AssistantTurn(
            id = turnSeq++,
            role = "heretic",
            badge = "HERETIC READY",
            text = "Heretic Voice Assistant online (100% offline, zero network permissions). " +
                "Say \"Heretic\" (or \"Hey Heretic <command>\") in hands-free mode, say \"shaz\" anytime to interrupt playback, or open Models to activate Parakeet STT, llama.cpp GGUF, LiteRT-LM, and Supertonic TTS.",
            spokenText = "Heretic Voice Assistant online.",
        )

        _state = MutableStateFlow(
            VoicePipelineUiState(
                paths = initialPaths,
                readiness = initialReadiness,
                tfliteSummary = tfliteEngine?.statusSummary()
                    ?: "LiteRT 2.3.0 + litert-gpu 2.3.0 ready (TFL3 v3 · GPU -> setNumThreads(4) cached per install)",
                wakeWordRequired = savedWakeRequired,
                voiceSpeed = savedSpeed,
                diffusionSteps = savedSteps,
                availableStyles = styles,
                savedWavs = listSavedWavFiles(),
                lexiconRules = loadedLexicon,
                milestones = loadedMilestones,
                statusMessage = buildTierStatusSummary(initialReadiness),
                conversation = listOf(welcomeTurn),
            )
        )
        state = _state.asStateFlow()

        if (initialReadiness.llmReady || initialReadiness.sttReady || (initialReadiness.ttsReady && initialReadiness.styleReady)) {
            initialize()
        }
        tryBootInstalledLiteRt()
    }

    private fun seedInitialAssistantGrants() {
        val prefs = appContext.getSharedPreferences(PREFS_ASSISTANT, Context.MODE_PRIVATE)
        if (!prefs.getBoolean(KEY_INITIAL_TTS_GATE, false)) {
            hereticCore.gates.record("tts.speak", "GRANTED", source = "voice-assistant-init")
            hereticCore.gates.record("mic.capture", "GRANTED", source = "voice-assistant-init")
            prefs.edit().putBoolean(KEY_INITIAL_TTS_GATE, true).apply()
        }
    }

    private fun tryBootInstalledLiteRt() {
        val engine = liteRtEngine ?: return
        val installed = engine.installedModel() ?: return
        scope.launch(Dispatchers.IO) {
            runCatching { engine.load(installed) }.onSuccess {
                mutateState {
                    it.copy(
                        liteRtActive = true,
                        liteRtModelLabel = "${installed.label} · ${engine.activeBackendLabel}",
                    )
                }
            }
        }
    }

    fun consumeTabNavigation() {
        mutateState { it.copy(requestedTab = null) }
    }

    // ------------------------------------------------------------------------
    // Multi-Format RAG Ingestion & Best-Chunk Retrieval
    // ------------------------------------------------------------------------

    fun setRagTargetFilter(filter: String) {
        mutateState { it.copy(ragTargetFilter = filter.trim()) }
    }

    fun clearRagIndex() {
        ragChunks.clear()
        _state.update {
            it.copy(
                ragIndexedFiles = emptyList(),
                ragStatus = "No RAG files or folders indexed",
            )
        }
    }

    fun importRagFile(uri: Uri, displayName: String) {
        mutateState { it.copy(isBusy = true, statusMessage = "Indexing file into RAG memory...") }
        scope.launch(Dispatchers.IO) {
            val added = runCatching { ingestDocumentUri(uri, displayName) }.getOrDefault(0)
            updateRagSummary(added)
        }
    }

    fun importRagFolder(treeUri: Uri) {
        mutateState { it.copy(isBusy = true, statusMessage = "Indexing folder recursively into RAG memory...") }
        scope.launch(Dispatchers.IO) {
            val added = runCatching { ingestTreeUri(treeUri) }.getOrDefault(0)
            updateRagSummary(added)
        }
    }

    private fun updateRagSummary(addedChunks: Int) {
        val sources = ragChunks.map { it.sourcePath }.distinct()
        val status = if (ragChunks.isEmpty()) {
            "No readable text found in selection"
        } else {
            "RAG ready: ${ragChunks.size} chunks across ${sources.size} file(s)"
        }
        _state.update {
            it.copy(
                isBusy = false,
                ragIndexedFiles = sources,
                ragStatus = status,
                statusMessage = if (addedChunks > 0) "Indexed $addedChunks chunk(s) into local RAG." else "No readable text found.",
            )
        }
    }

    private fun ingestTreeUri(treeUri: Uri): Int {
        val rootDocId = DocumentsContract.getTreeDocumentId(treeUri)
        var totalAdded = 0
        val queue = ArrayDeque<Pair<String, String>>()
        queue.addLast(rootDocId to "")

        while (queue.isNotEmpty() && ragChunks.size < MAX_TOTAL_RAG_CHUNKS) {
            val (docId, prefix) = queue.removeFirst()
            val childrenUri = DocumentsContract.buildChildDocumentsUriUsingTree(treeUri, docId)
            appContext.contentResolver.query(
                childrenUri,
                arrayOf(
                    DocumentsContract.Document.COLUMN_DOCUMENT_ID,
                    DocumentsContract.Document.COLUMN_DISPLAY_NAME,
                    DocumentsContract.Document.COLUMN_MIME_TYPE
                ),
                null,
                null,
                null,
            )?.use { cursor ->
                while (cursor.moveToNext()) {
                    val childId = cursor.getString(0) ?: continue
                    val name = cursor.getString(1) ?: childId.substringAfterLast('/')
                    val mime = cursor.getString(2).orEmpty()
                    val relativePath = if (prefix.isEmpty()) name else "$prefix/$name"

                    if (mime == DocumentsContract.Document.MIME_TYPE_DIR) {
                        queue.addLast(childId to relativePath)
                    } else if (isSupportedRagFileName(name, mime)) {
                        val fileUri = DocumentsContract.buildDocumentUriUsingTree(treeUri, childId)
                        totalAdded += ingestDocumentUri(fileUri, displayPathOverride = relativePath)
                    }
                }
            }
        }
        return totalAdded
    }

    private fun ingestDocumentUri(uri: Uri, displayPathOverride: String): Int {
        var added = 0
        appContext.contentResolver.openInputStream(uri)?.use { rawStream ->
            val stream = BufferedInputStream(rawStream)
            val lowerName = displayPathOverride.lowercase()
            if (lowerName.endsWith(".zip")) {
                ZipInputStream(stream).use { zis ->
                    var entry = zis.nextEntry
                    while (entry != null && ragChunks.size < MAX_TOTAL_RAG_CHUNKS) {
                        val entryName = entry.name
                        if (!entry.isDirectory && isSupportedRagFileName(entryName, "")) {
                            val bytes = zis.readBytes()
                            val text = extractReadableText(entryName, bytes)
                            added += indexTextIntoPages("$displayPathOverride/$entryName", text)
                        }
                        zis.closeEntry()
                        entry = zis.nextEntry
                    }
                }
            } else {
                val bytes = stream.readBytes()
                val text = extractReadableText(displayPathOverride, bytes)
                added += indexTextIntoPages(displayPathOverride, text)
            }
        }
        return added
    }

    private fun extractReadableText(fileName: String, bytes: ByteArray): String {
        if (bytes.isEmpty()) return ""
        if (fileName.lowercase().endsWith(".pdf")) {
            val rawLatin = String(bytes, Charsets.ISO_8859_1)
            val extracted = Regex("\\(([^()\\\\]{3,})\\)")
                .findAll(rawLatin)
                .map { it.groupValues[1] }
                .joinToString(" ")
                .replace(Regex("\\s+"), " ")
                .trim()
            if (extracted.length >= 20) return extracted
        }
        return bytes.toString(Charsets.UTF_8)
            .replace("\u0000", " ")
            .trim()
    }

    private fun indexTextIntoPages(sourcePath: String, fullText: String): Int {
        val cleaned = fullText.trim()
        if (cleaned.isEmpty()) return 0

        ragChunks.removeAll { it.sourcePath.equals(sourcePath, ignoreCase = true) }

        val rawPages = if (cleaned.contains('\u000C')) {
            cleaned.split('\u000C')
        } else {
            cleaned.chunked(CHARS_PER_RAG_PAGE)
        }

        var pageNum = 1
        var added = 0
        for (page in rawPages) {
            val trimmed = page.trim()
            if (trimmed.isNotEmpty() && ragChunks.size < MAX_TOTAL_RAG_CHUNKS) {
                val tokens = tokenizeForRag("$sourcePath page $pageNum $trimmed")
                ragChunks.add(
                    RagChunk(
                        sourcePath = sourcePath,
                        pageNumber = pageNum,
                        content = trimmed,
                        tokens = tokens,
                    )
                )
                pageNum++
                added++
            }
        }
        return added
    }

    fun retrieveBestRagContext(query: String): String? {
        if (ragChunks.isEmpty()) return null

        val filter = _state.value.ragTargetFilter.trim().lowercase()
        val queryLower = query.lowercase()
        val pageRegex = Regex("page\\s*(\\d+)")
        val requestedPage = pageRegex.find(queryLower)?.groupValues?.getOrNull(1)?.toIntOrNull()
            ?: pageRegex.find(filter)?.groupValues?.getOrNull(1)?.toIntOrNull()
        val fileFilter = filter.replace(pageRegex, "").trim()

        val candidates = ragChunks.filter { chunk ->
            val matchesFile = fileFilter.isEmpty() || chunk.sourcePath.lowercase().contains(fileFilter)
            val matchesPage = requestedPage == null || chunk.pageNumber == requestedPage
            matchesFile && matchesPage
        }.ifEmpty { ragChunks.toList() }

        val queryTokens = tokenizeForRag(query)
        val ranked = candidates.map { chunk ->
            val overlap = queryTokens.count { it in chunk.tokens }
            val pathBonus = if (queryTokens.any { chunk.sourcePath.lowercase().contains(it) }) 3 else 0
            val pageBonus = if (requestedPage != null && chunk.pageNumber == requestedPage) 5 else 0
            chunk to (overlap + pathBonus + pageBonus)
        }.sortedWith(compareByDescending<Pair<RagChunk, Int>> { it.second }.thenBy { it.first.pageNumber })
            .take(3)

        if (ranked.isEmpty()) return null
        return ranked.joinToString("\n\n") { (chunk, _) ->
            "[${chunk.sourcePath} p.${chunk.pageNumber}]:\n${chunk.content.take(450)}"
        }
    }

    private fun tokenizeForRag(text: String): Set<String> {
        val stopWords = setOf(
            "the", "and", "for", "that", "this", "with", "from", "what", "where",
            "when", "which", "who", "how", "are", "was", "were", "have", "has",
            "had", "can", "could", "would", "should", "about", "into", "your"
        )
        return text.lowercase()
            .replace(Regex("[^a-z0-9 ]"), " ")
            .split(Regex("\\s+"))
            .map { it.trim() }
            .filter { it.length >= 2 && it !in stopWords }
            .toSet()
    }

    private fun isSupportedRagFileName(name: String, mime: String): Boolean {
        val lower = name.lowercase()
        if (lower.startsWith(".")) return false
        return mime.startsWith("text/") ||
            lower.endsWith(".txt") ||
            lower.endsWith(".md") ||
            lower.endsWith(".json") ||
            lower.endsWith(".csv") ||
            lower.endsWith(".kt") ||
            lower.endsWith(".java") ||
            lower.endsWith(".py") ||
            lower.endsWith(".xml") ||
            lower.endsWith(".html") ||
            lower.endsWith(".pdf") ||
            lower.endsWith(".zip")
    }

    // ------------------------------------------------------------------------

    fun initialize(onComplete: ((Boolean) -> Unit)? = null) {
        val currentPaths = VoiceModelConfigStore.loadPaths(appContext)
        val readiness = VoiceModelConfigStore.validate(currentPaths)
        if (!readiness.llmReady && !readiness.sttReady && !(readiness.ttsReady && readiness.styleReady)) {
            mutateState {
                it.copy(
                    paths = currentPaths,
                    readiness = readiness,
                    isInitialized = false,
                    sttNeuralActive = false,
                    llmNeuralActive = false,
                    ttsNeuralActive = false,
                    statusMessage = "Running on built-in offline engine (${it.activeSttLabel} · ${it.activeBrainLabel} · ${it.activeTtsLabel}). Import .gguf or .zip packs anytime.",
                )
            }
            onComplete?.invoke(false)
            return
        }

        mutateState {
            it.copy(
                isBusy = true,
                paths = currentPaths,
                readiness = readiness,
                statusMessage = "Booting available neural engines (ARM64 ONNX + llama.cpp JNI)...",
            )
        }

        scope.launch(Dispatchers.IO) {
            teardownOrchestrator()
            val player = PcmStreamingAudioPlayer()
            scope.launch {
                player.playingState.collect { playing ->
                    mutateState { s -> s.copy(isPlaying = playing) }
                }
            }

            val snap = _state.value
            val created = UnifiedVoiceOrchestrator(
                context = appContext,
                sttModelDir = File(currentPaths.sttModelDir),
                ttsModelDir = File(currentPaths.ttsModelDir),
                llamaModelPath = currentPaths.llamaModelPath,
                voiceStylePath = currentPaths.voiceStylePath,
                audioPlayer = player,
                autoPlayAudioTrack = true,
            ).apply {
                voiceSpeed = snap.voiceSpeed
                diffusionSteps = snap.diffusionSteps
            }

            val summary = runCatching { created.initModular(readiness) }.getOrElse { e ->
                Log.e(TAG, "UnifiedVoiceOrchestrator.initModular() threw exception", e)
                NeuralBootSummary(false, false, false)
            }

            if (summary.anyLoaded) {
                synchronized(controllerLock) {
                    orchestrator = created
                    initializedPaths = currentPaths
                }
                val loadedNames = buildList {
                    if (summary.sttLoaded) add("Parakeet STT")
                    if (summary.llmLoaded) add("llama.cpp GGUF")
                    if (summary.ttsLoaded) add("Supertonic TTS")
                }
                mutateState {
                    it.copy(
                        isBusy = false,
                        isInitialized = summary.allLoaded,
                        sttNeuralActive = summary.sttLoaded,
                        llmNeuralActive = summary.llmLoaded,
                        ttsNeuralActive = summary.ttsLoaded,
                        availableStyles = discoverAllStyles(File(currentPaths.ttsModelDir)),
                        statusMessage = "Activated neural tiers: ${loadedNames.joinToString(" + ")}.",
                    )
                }
                onComplete?.invoke(true)
            } else {
                created.shutdown()
                mutateState {
                    it.copy(
                        isBusy = false,
                        isInitialized = false,
                        sttNeuralActive = false,
                        llmNeuralActive = false,
                        ttsNeuralActive = false,
                        statusMessage = "Neural init fell back to built-in offline engine — verify imported model files.",
                    )
                }
                onComplete?.invoke(false)
            }
        }
    }

    fun startListening(): Boolean {
        if (!hereticCore.gates.granted("mic.capture")) {
            mutateState {
                it.copy(statusMessage = "Microphone blocked by Authorization Gate (mic.capture) — grant it in Gates tab.")
            }
            return false
        }
        if (!PermissionHelper.hasRecordPermission(appContext)) {
            onRequestRecordPermission?.invoke()
            mutateState {
                it.copy(statusMessage = "Microphone permission required — grant RECORD_AUDIO to speak.")
            }
            return false
        }

        val active = synchronized(controllerLock) { orchestrator }
        if (active != null && active.sttLoaded) {
            active.startHandsFreeCapture(
                onUtterance = { transcript ->
                    handleSpokenOrTypedTurn(transcript, fromMic = true, fromHandsFreeStream = true)
                },
                onBargeIn = {
                    platformVoice?.stop()
                    mutateState { it.copy(statusMessage = "VAD barge-in detected — audio flushed, listening...") }
                },
                onError = { err ->
                    mutateState { it.copy(isListening = false, statusMessage = "Parakeet STT error: $err") }
                },
            )
            mutateState {
                val modeHint = if (it.wakeWordRequired) {
                    "say \"Heretic\" to wake, or \"shaz\" to stop"
                } else {
                    "open mic active · say \"shaz\" anytime to stop"
                }
                it.copy(
                    isListening = true,
                    statusMessage = "Hands-free Parakeet TDT + Silero VAD v6 listening ($modeHint).",
                )
            }
            return true
        }

        val pv = platformVoice
        if (pv != null) {
            stopPlayback()
            mutateState {
                it.copy(
                    isListening = true,
                    statusMessage = "Listening via offline Android SpeechRecognizer...",
                )
            }
            var finalHandled = false
            pv.startListening(
                onResult = { transcript ->
                    val clean = transcript.trim()
                    if (clean.isNotEmpty() && !finalHandled) {
                        finalHandled = true
                        mutateState { it.copy(isListening = false) }
                        handleSpokenOrTypedTurn(clean, fromMic = true)
                    }
                },
                onError = { err ->
                    mutateState {
                        it.copy(
                            isListening = false,
                            statusMessage = "Speech recognition ended ($err) — import parakeet-tdt-stt-models.zip for continuous hands-free STT.",
                        )
                    }
                },
            )
            return true
        }

        mutateState {
            it.copy(statusMessage = "Import parakeet-tdt-stt-models.zip in Models tab to enable microphone capture.")
        }
        return false
    }

    fun stopListening() {
        synchronized(controllerLock) { orchestrator }?.stopListening()
        platformVoice?.stop()
        mutateState {
            it.copy(
                isListening = false,
                statusMessage = "Microphone capture stopped.",
            )
        }
    }

    fun stopPlayback() {
        synchronized(controllerLock) { orchestrator }?.stopPlayback()
        platformVoice?.stop()
        mutateState {
            it.copy(
                isPlaying = false,
                statusMessage = "SHAZ · Playback paused & flushed immediately.",
            )
        }
    }

    fun speakPrompt(prompt: String) {
        handleSpokenOrTypedTurn(prompt, fromMic = false)
    }

    fun speakTextAloud(text: String) {
        if (!hereticCore.gates.granted("tts.speak")) {
            mutateState { it.copy(statusMessage = "Audible output muted by Gate (tts.speak).") }
            return
        }
        val active = synchronized(controllerLock) { orchestrator }
        if (active != null && active.ttsLoaded) {
            active.speakDirectText(
                text = text,
                fallbackSpeak = { platformVoice?.speak(it) },
            )
        } else {
            platformVoice?.speak(text)
        }
    }

    fun setWakeWordRequired(required: Boolean) {
        wakeGate.wakeWordRequired = required
        if (!required) {
            wakeGate.sleep()
        }
        appContext.getSharedPreferences(PREFS_ASSISTANT, Context.MODE_PRIVATE)
            .edit()
            .putBoolean(KEY_WAKE_WORD_REQUIRED, required)
            .apply()
        mutateState {
            it.copy(
                wakeWordRequired = required,
                statusMessage = if (required) {
                    "Wake Gate ON — Hands-free listening waits for wake word \"Heretic\" (say \"shaz\" anytime to interrupt)."
                } else {
                    "Wake Gate OFF — Hands-free open-mic listening active (say \"shaz\" anytime to interrupt)."
                },
            )
        }
    }

    fun toggleWakeWordRequired() {
        setWakeWordRequired(!_state.value.wakeWordRequired)
    }

    fun clearConversation() {
        mutateState {
            it.copy(
                conversation = emptyList(),
                transcriptHistory = emptyList(),
                statusMessage = "Cleared conversation history.",
            )
        }
    }

    private fun handleSpokenOrTypedTurn(
        rawInput: String,
        fromMic: Boolean,
        fromHandsFreeStream: Boolean = false,
    ) {
        val rawTrimmed = rawInput.trim()
        if (rawTrimmed.isEmpty()) return

        val gateDecision = wakeGate.evaluate(
            rawTranscript = rawTrimmed,
            fromHandsFreeStream = fromHandsFreeStream,
        )

        val trimmed = when (gateDecision) {
            WakeGateDecision.IgnoredAmbient -> {
                mutateState {
                    it.copy(
                        statusMessage = "Standby (Wake Word \"Heretic\") · Ignored unprefixed room speech.",
                    )
                }
                return
            }

            WakeGateDecision.ImmediateStop -> {
                stopPlayback()
                appendTurn("you", if (fromMic) "MIC" else "YOU", rawTrimmed)
                appendTurn("action", "SHAZ INTERRUPT", "Playback halted and AudioTrack flushed immediately.")
                return
            }

            WakeGateDecision.WakeAcknowledged -> {
                val ackText = "HERETIC AWAKE · Hands-free command window open (20s). Speak your command, or say \"shaz\" anytime to interrupt."
                val ackSpeak = "Heretic awake and listening. Go ahead."
                appendTurn("you", if (fromMic) "WAKE WORD" else "YOU", rawTrimmed)
                appendTurn("action", "WAKE · HERETIC", ackText, spoken = ackSpeak)
                mutateState {
                    it.copy(
                        lastAssistantSentence = ackSpeak,
                        statusMessage = "Wake word \"Heretic\" detected — listening for follow-up command (20s window)...",
                    )
                }
                speakTextAloud(ackSpeak)
                return
            }

            is WakeGateDecision.Execute -> {
                appendTurn(
                    role = "you",
                    badge = when {
                        gateDecision.wokeNow && fromMic -> "WAKE · HERETIC"
                        fromMic -> "VOICE"
                        else -> "YOU"
                    },
                    text = rawTrimmed,
                )
                gateDecision.command
            }
        }

        val routed: RoutedAssistantResult? = VoiceActionRouter.tryExecuteCommand(
            rawInput = trimmed,
            core = hereticCore,
            milestonesProvider = { _state.value.milestones },
            onUpdateMilestones = { updateMilestones(it) },
            onSaveLastWav = { saveLastSynthesizedWav() },
            onAddLexiconRule = { word, rep -> addLexiconRule(word, rep) },
            systemSummaryProvider = { buildSystemDiagnosticReport() },
            wakeWordRequiredProvider = { _state.value.wakeWordRequired },
            onSetWakeWordRequired = { setWakeWordRequired(it) },
        )

        if (routed != null) {
            if (routed.kind == AssistantActionKind.STOP_PLAYBACK) {
                stopPlayback()
                return
            }
            appendTurn(
                role = "action",
                badge = "ACTION · ${routed.kind.name.replace('_', ' ')}",
                text = routed.displayReply,
                spoken = routed.spokenReply,
            )
            mutateState {
                it.copy(
                    lastErrorAnalysis = routed.errorAnalysis ?: it.lastErrorAnalysis,
                    lastSolutionConfirmation = routed.solutionConfirmation ?: it.lastSolutionConfirmation,
                    lastFileAssessment = routed.fileAssessment ?: it.lastFileAssessment,
                    requestedTab = routed.targetTab,
                    statusMessage = "Executed ${routed.kind.name.lowercase().replace('_', ' ')}.",
                )
            }
            if (routed.spokenReply.isNotBlank()) {
                speakTextAloud(routed.spokenReply)
            }
            return
        }

        // Open-ended assistant query -> Inject RAG Context into prompt
        val bestRag = retrieveBestRagContext(trimmed)
        val enhancedPrompt = if (bestRag != null) {
            "Context Information:\n$bestRag\n\nQuestion: $trimmed"
        } else {
            trimmed
        }

        val active = synchronized(controllerLock) { orchestrator }
        if (active != null && active.llmLoaded) {
            val turnId = turnSeq++
            val placeholder = AssistantTurn(
                id = turnId,
                role = "heretic",
                badge = "LLAMA.CPP + RAG",
                text = "…",
            )
            mutateState { prev ->
                prev.copy(
                    conversation = (prev.conversation + placeholder).takeLast(MAX_CONVERSATION_TURNS),
                    statusMessage = "Streaming response with RAG context via llama.cpp...",
                )
            }
            val accumulated = StringBuilder()
            active.speakPrompt(
                prompt = enhancedPrompt,
                onAssistantSentence = { sentence ->
                    if (accumulated.isNotEmpty()) accumulated.append(' ')
                    accumulated.append(sentence)
                    val fullSoFar = accumulated.toString()
                    mutateState { prev ->
                        val updatedConv = prev.conversation.map { t ->
                            if (t.id == turnId) t.copy(text = fullSoFar, spokenText = fullSoFar) else t
                        }
                        val nextHist = (prev.transcriptHistory + "Heretic: $sentence").takeLast(MAX_TRANSCRIPT_HISTORY)
                        prev.copy(
                            lastAssistantSentence = sentence,
                            transcriptHistory = nextHist,
                            conversation = updatedConv,
                        )
                    }
                },
                fallbackSpeakSentence = { sentence ->
                    if (hereticCore.gates.granted("tts.speak")) {
                        platformVoice?.speak(sentence)
                    }
                },
            )
            return
        }

        val lrt = liteRtEngine
        if (lrt != null && _state.value.liteRtActive) {
            mutateState { it.copy(statusMessage = "Generating reply on LiteRT-LM with RAG...") }
            scope.launch(Dispatchers.IO) {
                val replyResult = runCatching { lrt.generate(enhancedPrompt) }
                val text = replyResult.getOrElse { "LiteRT-LM error: ${it.message}" }
                withContext(Dispatchers.Main.immediate) {
                    appendTurn("heretic", "LITERT-LM", text, spoken = text)
                    mutateState { it.copy(statusMessage = "Reply ready.") }
                    speakTextAloud(text)
                }
            }
            return
        }

        val coreReply = hereticCore.reply(enhancedPrompt)
        val finalSpeak = if (bestRag != null) "From your indexed documents: ${coreReply.speak}" else coreReply.speak
        val finalText = if (bestRag != null) "From your indexed documents:\n$bestRag\n\n${coreReply.text}" else coreReply.text

        appendTurn(
            role = "heretic",
            badge = "HERETIC CORE + RAG",
            text = finalText,
            spoken = finalSpeak,
        )
        mutateState {
            it.copy(
                lastAssistantSentence = finalSpeak,
                statusMessage = "Answered via HereticCore with local RAG context.",
            )
        }
        speakTextAloud(finalSpeak)
    }

    private fun appendTurn(role: String, badge: String, text: String, spoken: String = "") {
        val entryHist = "${if (role == "you") "You" else "Heretic"}: $text"
        val turn = AssistantTurn(
            id = turnSeq++,
            role = role,
            badge = badge,
            text = text,
            spokenText = spoken,
        )
        mutateState { prev ->
            prev.copy(
                lastUserTranscript = if (role == "you") text else prev.lastUserTranscript,
                transcriptHistory = (prev.transcriptHistory + entryHist).takeLast(MAX_TRANSCRIPT_HISTORY),
                conversation = (prev.conversation + turn).takeLast(MAX_CONVERSATION_TURNS),
            )
        }
    }

    private fun buildSystemDiagnosticReport(): Pair<String, String> {
        val snap = _state.value
        val ramMb = liteRtEngine?.totalRamBytes()?.let { it / 1_048_576L } ?: 0L
        val freeMb = (appContext.filesDir.usableSpace / 1_048_576L)
        val abi = Build.SUPPORTED_ABIS.firstOrNull() ?: "arm64-v8a"
        val brokenIdx = hereticCore.gates.verify()
        val display = buildString {
            appendLine("DEVICE -> ${Build.MANUFACTURER} ${Build.MODEL} · Android API ${Build.VERSION.SDK_INT} ($abi)")
            appendLine("MEMORY -> ${ramMb} MB RAM · ${freeMb} MB free internal storage")
            appendLine("WAKE / STOP  -> Wake word = \"Heretic\" (gate=${if (snap.wakeWordRequired) "ON" else "OPEN MIC"}) · Interrupt = \"shaz\"")
            appendLine("RAG KNOWLEDGE -> ${ragChunks.size} chunks indexed across ${snap.ragIndexedFiles.size} sources")
            appendLine("ACTIVE STT   -> ${snap.activeSttLabel}")
            appendLine("ACTIVE BRAIN -> ${snap.activeBrainLabel}")
            appendLine("ACTIVE TTS   -> ${snap.activeTtsLabel}")
            appendLine("GATE LEDGER  -> ${if (brokenIdx == -1) "SHA-256 chain intact" else "Broken at $brokenIdx"}")
        }
        val spoken = "Running on ${Build.MODEL}, ABI $abi. RAG knowledge base contains ${ragChunks.size} chunks. " +
            "Active speech engine is ${snap.activeSttLabel}, brain is ${snap.activeBrainLabel}."
        return display to spoken
    }

    fun onRecordPermissionResult(granted: Boolean) {
        if (granted) {
            mutateState { it.copy(statusMessage = "Microphone permission granted — starting voice capture...") }
            startListening()
        } else {
            mutateState { it.copy(statusMessage = "Microphone permission denied — grant RECORD_AUDIO to use voice.") }
        }
    }

    fun shutdown() {
        teardownOrchestrator()
        scope.cancel()
    }

    private fun teardownOrchestrator() {
        val old = synchronized(controllerLock) {
            val prev = orchestrator
            orchestrator = null
            initializedPaths = null
            prev
        }
        old?.shutdown()
        _state.update {
            it.copy(
                isInitialized = false,
                sttNeuralActive = false,
                llmNeuralActive = false,
                ttsNeuralActive = false,
                isListening = false,
                isPlaying = false,
            )
        }
    }

    private fun buildTierStatusSummary(r: VoiceModelReadiness): String = when {
        r.allReady -> "All 3 neural packs verified on disk (GGUF + Parakeet STT + Supertonic TTS)."
        r.llmReady || r.sttReady || (r.ttsReady && r.styleReady) ->
            "Hybrid mode active — verified neural packs run alongside built-in offline fallbacks."
        else ->
            "Voice Assistant ready offline. Import .gguf / STT .zip / TTS .zip in Models tab to upgrade."
    }

    private fun discoverAllStyles(ttsDir: File): List<File> {
        val resolved = VoiceModelConfigStore.findValidSlotRoot("tts", ttsDir, maxDepth = 3) ?: ttsDir
        val dirs = listOfNotNull(
            File(resolved, "voice_styles"),
            resolved.parentFile?.let { File(it, "voice_styles") },
        )
        for (dir in dirs) {
            if (!dir.isDirectory) continue
            val styles = dir.listFiles()
                ?.filter { it.isFile && it.extension.equals("json", ignoreCase = true) }
                ?.sortedBy { it.name }
                .orEmpty()
            if (styles.isNotEmpty()) return styles
        }
        return emptyList()
    }

    private fun listSavedWavFiles(): List<File> {
        val dir = File(appContext.filesDir, "saved_audio")
        if (!dir.isDirectory) return emptyList()
        return dir.listFiles()
            ?.filter { it.isFile && it.extension.equals("wav", ignoreCase = true) }
            ?.sortedByDescending { it.lastModified() }
            .orEmpty()
    }

    private fun loadPersistedMilestones(): List<MilestoneItem> {
        val prefs = appContext.getSharedPreferences(PREFS_ASSISTANT, Context.MODE_PRIVATE)
        val raw = prefs.getString(KEY_MILESTONES, null)
        if (!raw.isNullOrBlank()) {
            val parsed = runCatching {
                val arr = JSONArray(raw)
                (0 until arr.length()).map { idx ->
                    val o = arr.getJSONObject(idx)
                    MilestoneItem(
                        title = o.getString("title"),
                        kind = MilestoneKind.valueOf(o.getString("kind")),
                        done = o.getBoolean("done"),
                    )
                }
            }.getOrNull()
            if (!parsed.isNullOrEmpty()) return parsed
        }
        return listOf(
            MilestoneItem("Native Jetpack Compose Heretic Voice Assistant shell", MilestoneKind.IMPLEMENT_NOW, true),
            MilestoneItem("ARM64 llama.cpp JNI + SentenceStreamingBuffer", MilestoneKind.IMPLEMENT_NOW, true),
            MilestoneItem("Parakeet TDT STT + built-in Silero VAD v6", MilestoneKind.IMPLEMENT_NOW, true),
            MilestoneItem("Supertonic ONNX TTS + low-latency AudioTrack shaz barge-in", MilestoneKind.IMPLEMENT_NOW, true),
            MilestoneItem("SAF .gguf / .litertlm / .zip offline model importer", MilestoneKind.IMPLEMENT_NOW, true),
            MilestoneItem("Multi-format local RAG knowledge indexing & retrieval", MilestoneKind.IMPLEMENT_NOW, true),
        )
    }

    private fun persistMilestones(items: List<MilestoneItem>) {
        val arr = JSONArray()
        for (item in items) {
            arr.put(
                JSONObject().apply {
                    put("title", item.title)
                    put("kind", item.kind.name)
                    put("done", item.done)
                }
            )
        }
        appContext.getSharedPreferences(PREFS_ASSISTANT, Context.MODE_PRIVATE)
            .edit()
            .putString(KEY_MILESTONES, arr.toString())
            .apply()
    }

    private fun mutateState(reducer: (VoicePipelineUiState) -> VoicePipelineUiState) {
        val updated = _state.updateAndGetCompat(reducer)
        onStateBroadcast?.invoke(updated)
    }

    private fun <T> MutableStateFlow<T>.updateAndGetCompat(function: (T) -> T): T {
        while (true) {
            val prevValue = value
            val nextValue = function(prevValue)
            if (compareAndSet(prevValue, nextValue)) {
                return nextValue
            }
        }
    }
}
